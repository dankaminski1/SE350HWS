package shop.ui;

public final class UIError extends Error {
}