package hw3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.Comparator;

public class fp {
	
static <U,V> List<V> map(Iterable<U> l, Function<U,V> f) {
	List<V> result = new ArrayList<V>(); // Stores the values after hashing with f

	// Loop to hash each function with f and store into result
	for (Iterator<U> iter = l.iterator(); iter.hasNext();) {
		result.add(f.apply(iter.next()));
	}

	return result;
}


static <U,V> V foldLeft(V e, Iterable<U>l, BiFunction<V,U,V> f){
	if (l != null) {
		if (l.iterator().hasNext() && l != null) { // Determines if there is a next element
			List<U> tail = new ArrayList<>(); // Will store the remaining elements in the iterable
			l.forEach(tail::add); // Populates list with remaining

			// Does the foldLeft operation
			return foldLeft(f.apply(e, l.iterator().next()), tail.subList(1, tail.size()), f);
		} else
			return e;
	} else
		return e;
}




static <U,V> V foldRight(V e, List<U> l, BiFunction<U,V,V> f){
	if (l != null) {
		if (l.iterator().hasNext()) {
			U head = l.iterator().next();
			return f.apply(head, foldRight(e, l.subList(1, l.size()), f));
		} else
			return e;
	} else
		return e;
}


static <U> Iterable<U> filter(Iterable<U> l, Predicate<U> p){
	for (Iterator<U> iter = l.iterator(); iter.hasNext();) {
		U value = iter.next(); // Gets object
		if (p.test(value)) { // Test value and removes if necessary
			iter.remove();
		}
	}
	return l; // Filtered list
}
static <U> U minVal(Iterable<U> l, Comparator<U> c){
	// write using fold.  No other loops or recursion permitted. 
	 return foldLeft(l.iterator().next(), l, (u, u2) -> c.compare(u, u2) < 0 ? u : u2);
}

static <U extends Comparable<U>> int minPos(Iterable<U> l){
	// write using fold.  No other loops or recursion permitted. 
	return 0;
}

	public static void main(String[] args) {
		// (1) Use map to implement the following behavior (described in Python).  i.e given a List<T> create a List<Integer> of the hashes of the objects.
		// names = ['Mary', 'Isla', 'Sam']
		// for i in range(len(names)):
		       // names[i] = hash(names[i])
		
		// (2) Use foldleft to calculate the sum of a list of integers.
		// i.e write a method: int sum(List<Integer> l)
		
		// (3) Use foldRight to concatenate a list of strings i.e write a method
		// String s (List<String> l)
		
		// (4) consider an array of Persons. Use filter to 
		// print the names of the Persons whose salary is
		// greater than 100000
		
		// (5) Use minVal to calculate the minimum of a List of 
		//       Integers
		
        // (6) Use minVal to calculate the maximum of a List of 
		//       Integers
		
		// (7)  Use minPos to calculate the position of the
		// minimum in  a List of  Integers

		// (8)  Use minPos to calculate the position of the
		// minimum in  a List of  String
	}

}

class Person{
	final int salary;
	final String name;
	
	Person(int salary, String name){
		this.salary = salary;
		this.name = name;
	}
	
	int getSalary() { return salary; }
	String name() { return name;}
	
}